# Docker enabled testing

This directory contains scripts to run the IOR benchmark testing in various Docker images.
This allows for testing several distributions on a developer machine.

To setup your test systems run:
  ./prepare.sh

To run all tests for all variants use
  ./run-all-tests.sh
