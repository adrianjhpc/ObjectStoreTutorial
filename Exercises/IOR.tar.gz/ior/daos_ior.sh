#!/bin/bash

#SBATCH --nodes=1
#SBATCH --time=00:10:00
#SBATCH --job-name=daos_ior
#SBATCH --nvram-option=1LM:1000
#SBATCH -o /home/nx04/nx04/$USER/PMTutorial/Exercises/ior/daos_ior.%A.out
#SBATCH -e /home/nx04/nx04/$USER/PMTutorial/Exercises/ior/daos_ior.%A.err
#SBATCH --partition=normal
#SBATCH --cpus-per-task=1
#SBATCH --ntasks-per-socket=24
#SBATCH --distribution=block:block


export NODES=$SLURM_JOB_NUM_NODES
export PROCS_PER_NODE=48
export NPROCS=$((NODES*PROCS_PER_NODE))
export I_MPI_HYDRA_TOPOLIB=



export PSM2_MULTI_EP=0

export PSM2_MULTIRAIL=1
export PSM2_MULTIRAIL_MAP=0:1,1:1
export PSM2_MULTI_EP=1
export PSM2_DEVICES="self,shm,hfi"

export FI_PROVIDER=tcp;rxm
export I_MPI_DEBUG=5


module load compiler
module load mpich/3.4.3
module load pmdk

export OMP_NUM_THREADS=1
srun --cpu-bind=core -N $NODES -n $NPROCS  /lustre/home/nx04/nx04/$USER/ior/src/ior -v -a DFS -w -W -r -R -o /test2.$SLURM_JOB_ID -b 1G -t 1m -C  --dfs.pool cc290816-37e4-49ad-906c-5f1389cca819 --dfs.cont ADD_CONTAINER_ID_HERE --dfs.oclass SX

