#!/bin/bash

#SBATCH --nodes=2
#SBATCH --time=00:10:00
#SBATCH --job-name=dfs_ior
#SBATCH -o daos_dfs_ior.%A.out
#SBATCH -e daos_dfs_ior.%A.err
#SBATCH --tasks-per-node=32
#SBATCH --cpus-per-task=1

module load openmpi 

pool=default-pool
cont=default-container

export pool=default-pool
export cont=default-container

srun src/ior  -v -a DFS -C -e -w -r -o /test2.$SLURM_JOB_ID -b 128m -t 1m -F --dfs.pool $pool --dfs.cont $cont #--dfs.dir_oclass SX


