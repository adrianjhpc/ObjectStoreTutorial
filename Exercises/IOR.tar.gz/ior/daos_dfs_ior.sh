#!/bin/bash

#SBATCH --nodes=2
#SBATCH --time=00:10:00
#SBATCH --job-name=dfs_ior
#SBATCH -o daos_dfs_ior.%A.out
#SBATCH -e daos_dfs_ior.%A.err
#SBATCH --tasks-per-node=48
#SBATCH --cpus-per-task=1
#SBATCH --nvram-options=1LM:1000

module load mpi
module load compiler
module load gnu/11.2.0
module load libfabric/latest 

export PSM2_MULTI_EP=1
export PSM2_MULTIRAIL=1
export PSM2_MULTIRAIL_MAP=0:1,1:1

export PSM2_DEVICES=self,hfi,shm

export DAOS_AGENT_DRPC_DIR=/var/daos_agent

export FI_PROVIDER_PATH=/home/software/libfabric/latest/lib

pool=default-pool
cont=default-container

export pool=default-pool
export cont=default-container

srun src/ior  -v -a DFS -C -e -w -r -o /test.$SLURM_JOB_ID -b 128m -t 1m -F --dfs.pool $pool --dfs.cont $cont #--dfs.dir_oclass SX


