#!/bin/bash

#SBATCH --nodes=2
#SBATCH --time=00:10:00
#SBATCH --job-name=dfs_ior
#SBATCH -o daos_dfs_ior.%A.out
#SBATCH -e daos_dfs_ior.%A.err
#SBATCH --tasks-per-node=48
#SBATCH --cpus-per-task=1
#SBATCH --nvram-options=1LM:1000

export HFI_UNIT=1

module load gnu/11.2.0
module load openmpi/4.1.5-GNU11.2.0

export DAOS_AGENT_DRPC_DIR=/var/run/daos_agent

export DAOS_POOL=tutorial
export DAOS_CONT="ior_bench_${SLURM_JOB_ID}"

daos cont create "$DAOS_POOL" "$DAOS_CONT" --type=POSIX

export LD_LIBRARY_PATH=/usr/lib64:$LD_LIBRARY_PATH

cleanup() {
    daos cont destroy "$DAOS_POOL" "$DAOS_CONT" --force || true
}
trap cleanup EXIT

LD_PRELOAD=/usr/lib64/libfabric.so.1.22.1  mpirun -n 96 -N 48 --bind-to core --mca mtl psm2 --mca pml cm --mca btl ^openib  src/ior -v -a DFS -C -e -w -r -o /test2.$SLURM_JOB_ID -b 128m -t 1m -F --dfs.pool $DAOS_POOL --dfs.cont $DAOS_CONT #--dfs.dir_oclass SX


