#!/bin/bash

#SBATCH --nodes=2
#SBATCH --time=01:00:00
#SBATCH --job-name=daos_fuse_ior
#SBATCH --nvram-option=1LM:1000
#SBATCH -o /home/nx04/nx04/$USER/PMTutorial/Exercises/ior/daos_fuse_ior.%A.out
#SBATCH -e /home/nx04/nx04/$USER/PMTutorial/Exercises/ior/daos_fuse_ior.%A.err
#SBATCH --partition=normal
#SBATCH --cpus-per-task=1
#SBATCH --ntasks-per-socket=24
#SBATCH --distribution=block:block


export NODES=$SLURM_JOB_NUM_NODES
export PROCS_PER_NODE=48
export NPROCS=$((NODES*PROCS_PER_NODE))
export I_MPI_HYDRA_TOPOLIB=



export PSM2_MULTI_EP=0

export PSM2_MULTIRAIL=1
export PSM2_MULTIRAIL_MAP=0:1,1:1
export PSM2_MULTI_EP=1
export PSM2_DEVICES="self,shm,hfi"

#export FI_PROVIDER=tcp;rxm
export I_MPI_DEBUG=5


module load compiler
module load mpich/3.4.3
module load pmdk

srun -N $NODES -n $NODES mkdir /tmp/$USER-fuse

srun -N $NODES -n $NODES dfuse -m /tmp/$USER-fuse --disable-caching --pool tutorial --cont ADD_CONTAINER_NAME_HERE --foreground &

sleep 2

df -h /tmp/$USER-fuse

export OMP_NUM_THREADS=1
mpirun -n ${NPROCS} -ppn ${PROCS_PER_NODE} /lustre/home/nx04/nx04/$USER/ior/src/ior -v -a POSIX -w -W -r -R -o /tmp/$USER-fuse/test -b 1G -t 1m -C -F

srun -N $NODES -n $NODES fusermount -u /tmp/$USER-fuse
srun -N $NODES -n $NODES rm -fr /tmp/$USER-fuse

