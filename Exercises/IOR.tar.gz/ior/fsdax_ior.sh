#!/bin/bash

#SBATCH --nodes=1
#SBATCH --time=00:10:00
#SBATCH --job-name=fsdax_ior
#SBATCH --nvram-option=1LM:1000
#SBATCH --cpus-per-task=1
#SBATCH -o fsdax_ior.%A.out
#SBATCH -e fsdax_ior.%A.err

export NODES=1
export NPROCS=48

export PSM2_MULTIRAIL=1
export PSM2_MULTIRAIL_MAP=0:1,1:1
export PSM2_MULTI_EP=1
export PSM2_DEVICES="self,hfi,shm"
export I_MPI_HYDRA_TOPOLIB=

module load compiler
module load mpich/3.4.3

cd /home/nx01/nx01/adrianj/PMTutorial/Exercises/ior

export OMP_NUM_THREADS=1

cp test.script.easy.fsdax test.script

srun -n ${NODES} -N ${NODES} mkdir /mnt/pmem_fsdax0/data
srun -n ${NODES} -N ${NODES} mkdir /mnt/pmem_fsdax1/data

mpirun -n ${NPROCS} -ppn 48 /home/nx01/nx01/adrianj/PMTutorial/Exercises/ior/src/ior  -v -a POSIX -w -W -r -R -o /mnt/pmem_fsdax0/data -b 1G -t 1m -F


srun -n ${NODES} -N ${NODES} rm -fr /mnt/pmem_fsdax0/data
srun -n ${NODES} -N ${NODES} rm -fr /mnt/pmem_fsdax1/data

