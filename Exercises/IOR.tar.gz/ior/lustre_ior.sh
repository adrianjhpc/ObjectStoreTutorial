#!/bin/bash

#SBATCH --nodes=1
#SBATCH --time=00:20:00
#SBATCH --job-name=lustre_ior
#SBATCH --nvram-option=1LM:1000
#SBATCH -o lustre_ior.%A.out
#SBATCH -e lustre_ior.%A.err

export NODES=1
export NPROCS=48

export PSM2_MULTIRAIL=1
export PSM2_MULTIRAIL_MAP=0:1,1:1
export PSM2_MULTI_EP=1
export PSM2_DEVICES="self,hfi,shm"
export I_MPI_HYDRA_TOPOLIB=

cd /home/nx04/nx04/$USER/IOR/

export OMP_NUM_THREADS=1

mkdir data

module load compiler 
module load mpich/3.4.3

mpirun -n ${NPROCS} -ppn ${NPROCS} /home/nx01/nx01/adrianj/PMTutorial/Exercises/ior/src/ior  -v -a POSIX -w -W -r -R -o data/test -b 1G -t 1m -F

rm -fr data

