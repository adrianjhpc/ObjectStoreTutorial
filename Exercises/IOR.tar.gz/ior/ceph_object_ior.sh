#!/bin/bash

#SBATCH --nodes=2
#SBATCH --time=00:10:00
#SBATCH --job-name=librados_ior
#SBATCH -o ceph_object_ior.%A.out
#SBATCH -e ceph_object_ior.%A.err
#SBATCH --tasks-per-node=32
#SBATCH --cpus-per-task=1

module load openmpi 

pool=default-pool
cont=default-container

export pool=default-pool
export cont=default-container


srun src/ior  -v -a RADOS -C -e -w -r -o test -b 128m -t 1m -F --rados.user tutorial --rados.conf /opt/apps/ceph/ceph.conf --rados.pool default-pool

