Doxygen
=======

Click `here <../doxygen_html/index.html>`_ for doxygen.

This documentation utilities doxygen for parsing the c code. Therefore a doxygen
instances is created in the background anyway. This might be helpful as doxygen
produces nice call graphs.
