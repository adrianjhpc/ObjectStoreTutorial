#!/bin/bash

#SBATCH --nodes=2
#SBATCH --time=00:10:00
#SBATCH --job-name=dfuse_ior
#SBATCH -o daos_filesystem_ior.%A.out
#SBATCH -e daos_filesystem_ior.%A.err
#SBATCH --tasks-per-node=48
#SBATCH --cpus-per-task=1
#SBATCH --nvram-options=1LM:1000


export HFI_UNIT=1

module load gnu/11.2.0
module load openmpi/4.1.5-GNU11.2.0

export DAOS_AGENT_DRPC_DIR=/var/run/daos_agent

export DAOS_POOL=tutorial
export DAOS_CONT="ior_bench_${SLURM_JOB_ID}"

daos cont create "$DAOS_POOL" "$DAOS_CONT" --type=POSIX

export LD_LIBRARY_PATH=/usr/lib64:$LD_LIBRARY_PATH

cleanup() {
    daos cont destroy "$DAOS_POOL" "$DAOS_CONT" --force || true
}
trap cleanup EXIT

export DFUSE_PATH=/tmp/daos

mkdir -p $DFUSE_PATH/$USER

dfuse -f -o debug --mountpoint="$DFUSE_PATH" --pool="$DAOS_POOL" --container="$DAOS_CONT"

#dfuse --mountpoint=$DFUSE_PATH --pool=$DAOS_POOL --container=$DAOS_CONT

LD_PRELOAD=/usr/lib64/libfabric.so.1.22.1:/usr/lib64/libpil4dfs.so  mpirun -n 96 -N 48 --bind-to core --mca mtl psm2 --mca pml cm --mca btl ^openib src/ior -v -a POSIX -C -e -w -r -o $DFUSE_PATH/$USER/test -b 128m -t 1m -F

rm -fr $DFUSE_PATH/$USER

