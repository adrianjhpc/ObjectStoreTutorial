#!/bin/bash

#SBATCH --nodes=2
#SBATCH --time=00:10:00
#SBATCH --job-name=dfuse_ior
#SBATCH -o daos_filesystem_ior.%A.out
#SBATCH -e daos_filesystem_ior.%A.err
#SBATCH --tasks-per-node=48
#SBATCH --cpus-per-task=1
#SBATCH --nvram-options=1LM:1000

export HFI_UNIT=1

module load gnu/11.2.0
module load openmpi/4.1.5-GNU11.2.0

export DAOS_AGENT_DRPC_DIR=/var/run/daos_agent
export DAOS_POOL=tutorial
export DAOS_CONT="ior_bench_${SLURM_JOB_ID}"
export DFUSE_PATH="/tmp/daos_${SLURM_JOB_ID}"
export LD_LIBRARY_PATH=/usr/lib64:$LD_LIBRARY_PATH

cleanup() {
    mpirun -n "$SLURM_NNODES" -N 1 rm -rf "$DFUSE_PATH" 2>/dev/null || true
    daos cont destroy "$DAOS_POOL" "$DAOS_CONT" --force || true
}
trap cleanup EXIT

# 1. Create the POSIX container
daos cont create "$DAOS_POOL" "$DAOS_CONT" --type=POSIX

# 2. Create the local anchor directory on ALL nodes (no dfuse mount needed)
mpirun -n "$SLURM_NNODES" -N 1 mkdir -p "$DFUSE_PATH"

# 3. Create the test subdirectory inside DAOS via libpil4dfs
D_IL_MOUNT_POINT="$DFUSE_PATH" \
D_IL_POOL="$DAOS_POOL" \
D_IL_CONTAINER="$DAOS_CONT" \
LD_PRELOAD=/usr/lib64/libfabric.so.1.22.1:/usr/lib64/libpil4dfs.so \
mkdir -p "$DFUSE_PATH/$USER"

# 4. Run 96-rank IOR with libpil4dfs intercepting all POSIX calls directly into DAOS
mpirun -n 96 -N 48 \
    --bind-to core \
    --mca mtl psm2 --mca pml cm --mca btl ^openib --mca osc ^ucx --mca memory ^patcher \
    -x DAOS_AGENT_DRPC_DIR \
    -x D_IL_MOUNT_POINT="$DFUSE_PATH" \
    -x D_IL_POOL="$DAOS_POOL" \
    -x D_IL_CONTAINER="$DAOS_CONT" \
    -x D_IL_REPORT=0 \
    -x LD_PRELOAD=/usr/lib64/libpil4dfs.so \
    src/ior -v -a POSIX -C -e -w -r -o "$DFUSE_PATH/$USER/test" -b 128m -t 1m -F
