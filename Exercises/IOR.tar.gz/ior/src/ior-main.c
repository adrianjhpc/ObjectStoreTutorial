#include "ior.h"

int main(int argc, char **argv)
{
    return ior_main(argc, argv);
}
