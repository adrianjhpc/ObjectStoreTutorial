/******************************************************************************\
 *                                                                             *
 * Copyright (c) 2022 EPCC, The University of Edinburgh                        *
 * Written by Adrian Jackson a.jackson@epcc.ed.ac.uk                           *
 *                                                                             *
 *******************************************************************************
 *                                                                             *
 *                                                                             *
 * This file implements the abstract I/O interface for the ADIOS2 I/O library  *
 *                                                                             *
\******************************************************************************/



#include <stdio.h>              /* only for fprintf() */
#include <stdlib.h>
#include <sys/stat.h>
#include <adios2.h>
#include <mpi.h>

#include "aiori.h"              /* abstract IOR interface */
#include "utilities.h"
#include "iordef.h"


/**************************** P R O T O T Y P E S *****************************/

static IOR_offset_t SeekOffset(void *, IOR_offset_t, aiori_mod_opt_t *);
static void SetupDataSet(void *, int flags, aiori_mod_opt_t *);
static aiori_fd_t *ADIOS2_Create(char *, int flags, aiori_mod_opt_t *);
static aiori_fd_t *ADIOS2_Open(char *, int flags, aiori_mod_opt_t *);
static IOR_offset_t ADIOS2_Xfer(int, aiori_fd_t *, IOR_size_t *,
                           IOR_offset_t, IOR_offset_t, aiori_mod_opt_t *);
static void ADIOS2_Close(aiori_fd_t *, aiori_mod_opt_t *);
static void ADIOS2_Delete(char *, aiori_mod_opt_t *);
static char* ADIOS2_GetVersion();
static void ADIOS2_Fsync(aiori_fd_t *, aiori_mod_opt_t *);
static IOR_offset_t ADIOS2_GetFileSize(aiori_mod_opt_t *, char *);
static int ADIOS2_Access(const char *, int, aiori_mod_opt_t *);
static void ADIOS2_init_xfer_options(aiori_xfer_hint_t * params);
static int ADIOS2_check_params(aiori_mod_opt_t * options);

/************************** O P T I O N S *****************************/
typedef struct{
  mpiio_options_t mpio;
  
  int collective_md;
  int individualDataSets;          /* datasets not shared by all procs */
  int noFill;                      /* no fill in file creation */
  IOR_offset_t setAlignment;       /* alignment in bytes */
} ADIOS2_options_t;
/***************************** F U N C T I O N S ******************************/

static option_help * ADIOS2_options(aiori_mod_opt_t ** init_backend_options, aiori_mod_opt_t * init_values){
  ADIOS2_options_t * o = malloc(sizeof(ADIOS2_options_t));

  if (init_values != NULL){
    memcpy(o, init_values, sizeof(ADIOS2_options_t));
  }else{
    memset(o, 0, sizeof(ADIOS2_options_t));
    /* initialize the options properly */
    o->collective_md = 0;
    o->setAlignment = 1;
  }

  *init_backend_options = (aiori_mod_opt_t*) o;

  option_help h [] = {
    /* options imported from MPIIO */
    {0, "hdf5.hintsFileName","Full name for hints file", OPTION_OPTIONAL_ARGUMENT, 's', & o->mpio.hintsFileName},
    {0, "hdf5.showHints",    "Show MPI hints", OPTION_FLAG, 'd', & o->mpio.showHints},    
    /* generic options */
    {0, "hdf5.collectiveMetadata", "Use collectiveMetadata (available since ADIOS2-1.10.0)", OPTION_FLAG, 'd', & o->collective_md},
    {0, "hdf5.individualDataSets",        "Datasets not shared by all procs [not working]", OPTION_FLAG, 'd', & o->individualDataSets},
    {0, "hdf5.setAlignment",        "ADIOS2 alignment in bytes (e.g.: 8, 4k, 2m, 1g)", OPTION_OPTIONAL_ARGUMENT, 'd', & o->setAlignment},
    {0, "hdf5.noFill", "No fill in ADIOS2 file creation", OPTION_FLAG, 'd', & o->noFill},
    LAST_OPTION
  };
  option_help * help = malloc(sizeof(h));
  memcpy(help, h, sizeof(h));
  return help;
}


/************************** D E C L A R A T I O N S ***************************/

ior_aiori_t hdf5_aiori = {
        .name = "ADIOS2",
        .name_legacy = NULL,
        .create = ADIOS2_Create,
        .open = ADIOS2_Open,
        .xfer = ADIOS2_Xfer,
        .close = ADIOS2_Close,
        .delete = ADIOS2_Delete,
        .get_version = ADIOS2_GetVersion,
        .xfer_hints = ADIOS2_init_xfer_options,
        .fsync = ADIOS2_Fsync,
        .get_file_size = ADIOS2_GetFileSize,
        .statfs = aiori_posix_statfs,
        .mkdir = aiori_posix_mkdir,
        .rmdir = aiori_posix_rmdir,
        .access = ADIOS2_Access,
        .stat = aiori_posix_stat,
        .get_options = ADIOS2_options,
        .check_params = ADIOS2_check_params
};

static hid_t xferPropList;      /* xfer property list */
hid_t dataSet;                  /* data set id */
hid_t dataSpace;                /* data space id */
hid_t fileDataSpace;            /* file data space id */
hid_t memDataSpace;             /* memory data space id */
int newlyOpenedFile;            /* newly opened file */

/***************************** F U N C T I O N S ******************************/
static aiori_xfer_hint_t * hints = NULL;

static void ADIOS2_init_xfer_options(aiori_xfer_hint_t * params){
  hints = params;
  /** ADIOS2 utilizes the MPIIO backend too, so init hints there */
  MPIIO_xfer_hints(params);
}

static int ADIOS2_check_params(aiori_mod_opt_t * options){
  ADIOS2_options_t *o = (ADIOS2_options_t*) options;
  if (o->setAlignment < 0)
      ERR("alignment must be non-negative integer");
  if (o->individualDataSets)
      ERR("individual data sets not implemented");
  return 0;
}

/*
 * Create and open a file through the ADIOS2 interface.
 */
static aiori_fd_t *ADIOS2_Create(char *testFileName, int flags, aiori_mod_opt_t * param)
{
        return ADIOS2_Open(testFileName, flags, param);
}

/*
 * Open a file through the ADIOS2 interface.
 */
static aiori_fd_t *ADIOS2_Open(char *testFileName, int flags, aiori_mod_opt_t * param)
{
        ADIOS2_options_t *o = (ADIOS2_options_t*) param;
        hid_t accessPropList, createPropList;
        hsize_t memStart[NUM_DIMS],
            dataSetDims[NUM_DIMS],
            memStride[NUM_DIMS],
            memCount[NUM_DIMS], memBlock[NUM_DIMS], memDataSpaceDims[NUM_DIMS];
        int tasksPerDataSet;
        unsigned fd_mode = (unsigned)0;
        hid_t *fd;
        MPI_Comm comm;
        MPI_Info mpiHints = MPI_INFO_NULL;

        fd = (hid_t *) malloc(sizeof(hid_t));
        if (fd == NULL)
                ERR("malloc() failed");
        /*
         * ADIOS2 uses different flags than those for POSIX/MPIIO
         */
        /* set IOR file flags to ADIOS2 flags */
        /* -- file open flags -- */
        if (flags & IOR_RDONLY) {
                fd_mode |= H5F_ACC_RDONLY;
        }
        if (flags & IOR_WRONLY || flags & IOR_RDWR) {
                fd_mode |= H5F_ACC_RDWR;
        }
        if (flags & IOR_APPEND) {
                fprintf(stdout, "File append not implemented in ADIOS2\n");
        }
        if (flags & IOR_CREAT) {
                fd_mode |= H5F_ACC_CREAT;
        }
        if (flags & IOR_EXCL) {
                fd_mode |= H5F_ACC_EXCL;
        }
        if (flags & IOR_TRUNC) {
                fd_mode |= H5F_ACC_TRUNC;
        }
        if (flags & IOR_DIRECT) {
                fprintf(stdout, "O_DIRECT not implemented in ADIOS2\n");
        }

        /* set up file creation property list */
        createPropList = H5Pcreate(H5P_FILE_CREATE);
        ADIOS2_CHECK(createPropList, "cannot create file creation property list");
        /* set size of offset and length used to address ADIOS2 objects */
        ADIOS2_CHECK(H5Pset_sizes
                   (createPropList, sizeof(hsize_t), sizeof(hsize_t)),
                   "cannot set property list properly");

        /* set up file access property list */
        accessPropList = H5Pcreate(H5P_FILE_ACCESS);
        ADIOS2_CHECK(accessPropList, "cannot create file access property list");

        /*
         * someday ADIOS2 implementation will allow subsets of MPI_COMM_WORLD
         */
        /* store MPI communicator info for the file access property list */
        if (hints->filePerProc) {
                comm = MPI_COMM_SELF;
        } else {
                comm = testComm;
        }

        /*
         * note that with MP_HINTS_FILTERED=no, all key/value pairs will
         * be in the info object.  The info object that is attached to
         * the file during MPI_File_open() will only contain those pairs
         * deemed valid by the implementation.
         */
        /* show hints passed to file */
        SetHints(&mpiHints, o->mpio.hintsFileName);
        if (rank == 0 && o->mpio.showHints) {
                fprintf(stdout, "\nhints passed to access property list {\n");
                ShowHints(&mpiHints);
                fprintf(stdout, "}\n");
        }
        ADIOS2_CHECK(H5Pset_fapl_mpio(accessPropList, comm, mpiHints),
                   "cannot set file access property list");

        /* set alignment */
        ADIOS2_CHECK(H5Pset_alignment(accessPropList, o->setAlignment, o->setAlignment),
                   "cannot set alignment");

#ifdef HAVE_H5PSET_ALL_COLL_METADATA_OPS
        if (o->collective_md) {
                /* more scalable metadata */

                ADIOS2_CHECK(H5Pset_all_coll_metadata_ops(accessPropList, 1),
                        "cannot set collective md read");
                ADIOS2_CHECK(H5Pset_coll_metadata_write(accessPropList, 1),
                        "cannot set collective md write");
        }
#endif

        /* open file */
        if(! hints->dryRun){
          if (flags & IOR_CREAT) {     /* WRITE */
                  *fd = H5Fcreate(testFileName, H5F_ACC_TRUNC, createPropList, accessPropList);
                  ADIOS2_CHECK(*fd, "cannot create file");
          } else {                /* READ or CHECK */
                  *fd = H5Fopen(testFileName, fd_mode, accessPropList);
                  ADIOS2_CHECK(*fd, "cannot open file");
          }
        }

        /* show hints actually attached to file handle */
        if (o->mpio.showHints) {
                MPI_File *fd_mpiio;
                ADIOS2_CHECK(H5Fget_vfd_handle(*fd, accessPropList, (void **) &fd_mpiio), "cannot get file handle");
                MPI_Info info_used;
                MPI_CHECK(MPI_File_get_info(*fd_mpiio, &info_used), "cannot get file info");
                if (rank == 0) {
                        /* print the MPI file hints currently used */
                        fprintf(stdout, "\nhints returned from opened file {\n");
                        ShowHints(&info_used);
                                fprintf(stdout, "}\n");
                        }
                MPI_CHECK(MPI_Info_free(&info_used), "cannot free file info");
        }

        /* this is necessary for resetting various parameters
           needed for reopening and checking the file */
        newlyOpenedFile = TRUE;

        ADIOS2_CHECK(H5Pclose(createPropList),
                   "cannot close creation property list");
        ADIOS2_CHECK(H5Pclose(accessPropList),
                   "cannot close access property list");

        /* create property list for serial/parallel access */
        xferPropList = H5Pcreate(H5P_DATASET_XFER);
        ADIOS2_CHECK(xferPropList, "cannot create transfer property list");

        /* set data transfer mode */
        if (hints->collective) {
                ADIOS2_CHECK(H5Pset_dxpl_mpio(xferPropList, H5FD_MPIO_COLLECTIVE),
                           "cannot set collective data transfer mode");
        } else {
                ADIOS2_CHECK(H5Pset_dxpl_mpio
                           (xferPropList, H5FD_MPIO_INDEPENDENT),
                           "cannot set independent data transfer mode");
        }

        /* set up memory data space for transfer */
        memStart[0] = (hsize_t) 0;
        memCount[0] = (hsize_t) 1;
        memStride[0] = (hsize_t) (hints->transferSize / sizeof(IOR_size_t));
        memBlock[0] = (hsize_t) (hints->transferSize / sizeof(IOR_size_t));
        memDataSpaceDims[0] = (hsize_t) hints->transferSize;
        memDataSpace = H5Screate_simple(NUM_DIMS, memDataSpaceDims, NULL);
        ADIOS2_CHECK(memDataSpace, "cannot create simple memory data space");

        /* define hyperslab for memory data space */
        ADIOS2_CHECK(H5Sselect_hyperslab(memDataSpace, H5S_SELECT_SET,
                                       memStart, memStride, memCount,
                                       memBlock), "cannot create hyperslab");

        /* set up parameters for fpp or different dataset count */
        if (hints->filePerProc) {
                tasksPerDataSet = 1;
        } else {
                if (o->individualDataSets) {
                        /* each task in segment has single data set */
                        tasksPerDataSet = 1;
                } else {
                        /* share single data set across all tasks in segment */
                        tasksPerDataSet = hints->numTasks;
                }
        }
        dataSetDims[0] = (hsize_t) ((hints->blockSize / sizeof(IOR_size_t))
                                    * tasksPerDataSet);

        /* create a simple data space containing information on size
           and shape of data set, and open it for access */
        dataSpace = H5Screate_simple(NUM_DIMS, dataSetDims, NULL);
        ADIOS2_CHECK(dataSpace, "cannot create simple data space");
        if (mpiHints != MPI_INFO_NULL)
                MPI_Info_free(&mpiHints);

        return (aiori_fd_t*)(fd);
}

/*
 * Write or read access to file using the ADIOS2 interface.
 */
static IOR_offset_t ADIOS2_Xfer(int access, aiori_fd_t *fd, IOR_size_t * buffer,
                              IOR_offset_t length, IOR_offset_t offset, aiori_mod_opt_t * param)
{
        static int firstReadCheck = FALSE, startNewDataSet;
        IOR_offset_t segmentPosition, segmentSize;

        /*
         * this toggle is for the read check operation, which passes through
         * this function twice; note that this function will open a data set
         * only on the first read check and close only on the second
         */
        if (access == READCHECK) {
                if (firstReadCheck == TRUE) {
                        firstReadCheck = FALSE;
                } else {
                        firstReadCheck = TRUE;
                }
        }

        /* determine by offset if need to start new data set */
        if (hints->filePerProc == TRUE) {
                segmentPosition = (IOR_offset_t) 0;
                segmentSize = hints->blockSize;
        } else {
                segmentPosition =
                    (IOR_offset_t) ((rank + rankOffset) % hints->numTasks)
                    * hints->blockSize;
                segmentSize = (IOR_offset_t) (hints->numTasks) * hints->blockSize;
        }
        if ((IOR_offset_t) ((offset - segmentPosition) % segmentSize) ==
            0) {
                /*
                 * ordinarily start a new data set, unless this is the
                 * second pass through during a read check
                 */
                startNewDataSet = TRUE;
                if (access == READCHECK && firstReadCheck != TRUE) {
                        startNewDataSet = FALSE;
                }
        }

        if(hints->dryRun)
          return length;

        /* create new data set */
        if (startNewDataSet == TRUE) {
                /* if just opened this file, no data set to close yet */
                if (newlyOpenedFile != TRUE) {
                        ADIOS2_CHECK(H5Dclose(dataSet), "cannot close data set");
                        ADIOS2_CHECK(H5Sclose(fileDataSpace),
                                   "cannot close file data space");
                }
                SetupDataSet(fd, access == WRITE ? IOR_CREAT : IOR_RDWR, param);
        }

        SeekOffset(fd, offset, param);

        /* this is necessary to reset variables for reaccessing file */
        startNewDataSet = FALSE;
        newlyOpenedFile = FALSE;

        /* access the file */
        if (access == WRITE) {  /* WRITE */
                ADIOS2_CHECK(H5Dwrite(dataSet, H5T_NATIVE_LLONG,
                                    memDataSpace, fileDataSpace,
                                    xferPropList, buffer),
                           "cannot write to data set");
        } else {                /* READ or CHECK */
                ADIOS2_CHECK(H5Dread(dataSet, H5T_NATIVE_LLONG,
                                   memDataSpace, fileDataSpace,
                                   xferPropList, buffer),
                           "cannot read from data set");
        }
        return (length);
}

/*
 * Perform fsync().
 */
static void ADIOS2_Fsync(aiori_fd_t *fd, aiori_mod_opt_t * param)
{
        ADIOS2_CHECK(H5Fflush(*(hid_t *) fd, H5F_SCOPE_LOCAL), "cannot flush file to disk");
}

/*
 * Close a file through the ADIOS2 interface.
 */
static void ADIOS2_Close(aiori_fd_t *fd, aiori_mod_opt_t * param)
{
        if(hints->dryRun)
          return;
        //if (hints->fd_fppReadCheck == NULL) {
                ADIOS2_CHECK(H5Dclose(dataSet), "cannot close data set");
                ADIOS2_CHECK(H5Sclose(dataSpace), "cannot close data space");
                ADIOS2_CHECK(H5Sclose(fileDataSpace),
                           "cannot close file data space");
                ADIOS2_CHECK(H5Sclose(memDataSpace),
                           "cannot close memory data space");
                ADIOS2_CHECK(H5Pclose(xferPropList),
                           " cannot close transfer property list");
        //}
        ADIOS2_CHECK(H5Fclose(*(hid_t *) fd), "cannot close file");
        free(fd);
}

/*
 * Delete a file through the ADIOS2 interface.
 */
static void ADIOS2_Delete(char *testFileName, aiori_mod_opt_t * param)
{
  if(hints->dryRun)
    return
  MPIIO_Delete(testFileName, param);
  return;
}

/*
 * Determine api version.
 */
static char * ADIOS2_GetVersion()
{
  static char version[1024] = {0};
  if(version[0]) return version;

        unsigned major, minor, release;
        if (H5get_libversion(&major, &minor, &release) < 0) {
                WARN("cannot get ADIOS2 library version");
        } else {
                sprintf(version, "%u.%u.%u", major, minor, release);
        }
#ifndef H5_HAVE_PARALLEL
        strcat(version, " (Serial)");
#else                           /* H5_HAVE_PARALLEL */
        strcat(version, " (Parallel)");
#endif                          /* not H5_HAVE_PARALLEL */
  return version;
}

/*
 * Seek to offset in file using the ADIOS2 interface and set up hyperslab.
 */
static IOR_offset_t SeekOffset(void *fd, IOR_offset_t offset,
                                            aiori_mod_opt_t * param)
{
        ADIOS2_options_t *o = (ADIOS2_options_t*) param;
        IOR_offset_t segmentSize;
        hsize_t hsStride[NUM_DIMS], hsCount[NUM_DIMS], hsBlock[NUM_DIMS];
        hsize_t hsStart[NUM_DIMS];

        if (hints->filePerProc == TRUE) {
                segmentSize = (IOR_offset_t) hints->blockSize;
        } else {
                segmentSize =
                    (IOR_offset_t) (hints->numTasks) * hints->blockSize;
        }

        /* create a hyperslab representing the file data space */
        if (o->individualDataSets) {
                /* start at zero offset if not */
                hsStart[0] = (hsize_t) ((offset % hints->blockSize)
                                        / sizeof(IOR_size_t));
        } else {
                /* start at a unique offset if shared */
                hsStart[0] =
                    (hsize_t) ((offset % segmentSize) / sizeof(IOR_size_t));
        }
        hsCount[0] = (hsize_t) 1;
        hsStride[0] = (hsize_t) (hints->transferSize / sizeof(IOR_size_t));
        hsBlock[0] = (hsize_t) (hints->transferSize / sizeof(IOR_size_t));

        /* retrieve data space from data set for hyperslab */
        fileDataSpace = H5Dget_space(dataSet);
        ADIOS2_CHECK(fileDataSpace, "cannot get data space from data set");
        ADIOS2_CHECK(H5Sselect_hyperslab(fileDataSpace, H5S_SELECT_SET,
                                       hsStart, hsStride, hsCount, hsBlock),
                   "cannot select hyperslab");
        return (offset);
}

/*
 * Create ADIOS2 data set.
 */
static void SetupDataSet(void *fd, int flags, aiori_mod_opt_t * param)
{
        ADIOS2_options_t *o = (ADIOS2_options_t*) param;
        char dataSetName[MAX_STR];
        hid_t dataSetPropList;
        int dataSetID;
        static int dataSetSuffix = 0;

        /* may want to use an extendable dataset (H5S_UNLIMITED) someday */
        /* may want to use a chunked dataset (H5S_CHUNKED) someday */

        /* need to reset suffix counter if newly-opened file */
        if (newlyOpenedFile)
                dataSetSuffix = 0;

        /* may want to use individual access to each data set someday */
        if (o->individualDataSets) {
                dataSetID = (rank + rankOffset) % hints->numTasks;
        } else {
                dataSetID = 0;
        }

        sprintf(dataSetName, "%s-%04d.%04d", "Dataset", dataSetID,
                dataSetSuffix++);

        if (flags & IOR_CREAT) {     /* WRITE */
                /* create data set */
                dataSetPropList = H5Pcreate(H5P_DATASET_CREATE);
                if (o->noFill == TRUE) {
                        if (rank == 0 && verbose >= VERBOSE_1) {
                                fprintf(stdout, "\nusing 'no fill' option\n");
                        }
                        ADIOS2_CHECK(H5Pset_fill_time(dataSetPropList,
                                                    H5D_FILL_TIME_NEVER),
                                   "cannot set fill time for property list");
                }
                dataSet =
                    H5Dcreate(*(hid_t *) fd, dataSetName, H5T_NATIVE_LLONG,
                              dataSpace, dataSetPropList);
                ADIOS2_CHECK(dataSet, "cannot create data set");
        } else {                /* READ or CHECK */
                dataSet = H5Dopen(*(hid_t *) fd, dataSetName);
                ADIOS2_CHECK(dataSet, "cannot create data set");
        }
}

/*
 * Use MPIIO call to get file size.
 */
static IOR_offset_t
ADIOS2_GetFileSize(aiori_mod_opt_t * test, char *testFileName)
{
  if(hints->dryRun)
    return 0;
  return(MPIIO_GetFileSize(test, testFileName));
}

/*
 * Use MPIIO call to check for access.
 */
static int ADIOS2_Access(const char *path, int mode, aiori_mod_opt_t *param)
{
  if(hints->dryRun)
    return 0;
  return(MPIIO_Access(path, mode, param));
}
